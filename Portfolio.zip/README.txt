NEXT LEVEL PORTFOLIO TEMPLATE
==============================

Open index.html in VS Code and edit the text directly.

IMPORTANT FIX
-------------
The "Currently Learning" card was overlapping/going behind the profile photo.
It is now positioned as a separate visible card beside the photo on desktop,
and remains responsive on smaller screens.

QUICK EDITS
-----------
1. Profile photo:
   Replace assets/profile.jpg with your own photo.

2. Currently Learning card:
   Search for: "Currently Learning"
   Then edit the text, for example:
   Machine Learning
   NLP · AWS

3. Skills:
   Search for <div class="skill-card"> and edit/add skills.
   Devicon is used for real technology logos.

4. Projects:
   Edit the project title, description, tags and GitHub URL.

5. Social links:
   Search for "GitHub" and "LinkedIn" and replace URLs with your links.

6. Email:
   Replace the mailto address in the contact section and sendMail() function.

7. Resume:
   Replace assets/resume.pdf with your latest PDF, keeping the same filename.

8. Education / Certifications / Achievements:
   Edit the corresponding sections directly in index.html.

HOW TO RUN
----------
Double-click index.html to preview it, or open the folder in VS Code and use
Live Server for a better development experience.
